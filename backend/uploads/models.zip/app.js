const express = require('express')
const mongoose = require('mongoose')
var cors = require('cors')

const url = 'mongodb://localhost/blogposts'

const app = express()

mongoose.connect(url, {useNewUrlParser:true})
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log("Connected !!!")
});


app.use(cors())
app.use(express.json())
const alienRouter = require('./routes/signup')
app.use('/signup',alienRouter);


// app.use(cors())
// app.use(express.json())
const loginRouter = require('./routes/login')
app.use('/login',loginRouter);

const resetRouter = require('./routes/resetpassword')
app.use('/resetpassword',resetRouter);

const searchRouter = require('./routes/search')
app.use('/search',searchRouter);


const productRouter = require('./routes/product')
app.use('/product', productRouter);

const postRouter = require('./routes/blog_posts')
app.use('/createblog', postRouter);

app.listen(3000 , ()=>{
    console.log("Server started")
})