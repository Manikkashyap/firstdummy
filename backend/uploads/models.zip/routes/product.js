const express = require('express')
const router = express.Router()
const Product = require('../models/products')
const Joi = require('joi');

router.post('/:id' , async(req,res)=>{
    const joiSchema = Joi.object().keys({
        CompanyName:Joi.string().required(),
        ProductId:Joi.number().required(),
        ProductName:Joi.string().min(3).max(30).required(),
        Packs:Joi.number().required(),
        CalculatedStamps:Joi.number().required(),
    })

    const {body} = req;
    const alien = new Product({
        CompanyName:req.body.CompanyName,
        UserId:req.params.id,
        ProductId:req.body.ProductId,
        ProductName:req.body.ProductName,
        Packs:req.body.Packs,
        CalculatedStamps:req.body.CalculatedStamps
    })
    const result = joiSchema.validate(body,Product);
    const  {value , error} = result;
    const valid  = error == null;
    if(!valid){
      res.json({
        error:error
      })
    }
    else{
        const a1 =  await Product.findOne({ UserId :alien.UserId ,ProductId : alien.ProductId})
        // console.log(a1)
            if(a1 !== null){
                res.json({failure: " product already there in company's list !!"})
            }
            else{
                const a1 = await alien.save();
                res.json({success : "Your Data has been saved successfully "})
            }
    }
})



router.get('/:id' , async(req,res)=>{
    const id = req.params.id;
       const search = req.query.search;
        var pageNo = parseInt(req.query.pageNo)
        var size = parseInt(req.query.size)
        var query = {}
        if(pageNo < 0 || pageNo === 0) {
              response = {"error" : true,"message" : "invalid page number, should start with 1"};
              return res.json(response)
        }
        query.skip = size * (pageNo - 1)
        query.limit = size


    //   Product.estimatedDocumentCount( {} , (err , count)=>{
    //         console.log(">>>>>>>>>>>>>>>>>>>>>>" , count)
    //       })
             Product.find({UserId : id,ProductName : { $regex : search  , $options : '$i' }},{},query,function(err,data) {
              
                  if(err) {
                      response = {"error" : true,"message" : "Error fetching data"};
                  } else {
                      response = {"error" : false,"message" : data};
                  }
                  res.json(data)
              });
       })




       router.get('/:id/:productid', async(req,res)=> {
        const alien = new Product({
            UserId : req.params.id,
            ProductId : req.params.productid
        })
        const a1 = await Product.findOne({UserId: alien.UserId , ProductId : alien.ProductId})
        console.log(a1)
        if(a1){
            res.json(a1)
        }
        else {
            res.json({error : "Not Found any data !!"})
        }
    })      





router.delete('/:id/:productid' , async(req,res)=>{
    const id = req.params.id;
    const productid = req.params.productid;
            const b1 = await Product.findOneAndDelete({ UserId:id ,ProductId : productid})
           
            if( b1 !== null){
                res.json({success : "Product deleted succressfully !!"})
                console.log(b1);
            }
            else{
                res.json({error : "Could not delete Product Please try again."})
                console.log(b1);
               
            }
})

router.put('/:id' , async(req,res)=>{
    const joiSchema = Joi.object().keys({
        CompanyName:Joi.string().required(),
        ProductId:Joi.number().required(),
        ProductName:Joi.string().min(3).max(30).required(),
        Packs:Joi.number().required(),
        CalculatedStamps:Joi.number().required(),
    })

    const {body} = req;
    const alien = new Product({
        CompanyName:req.body.CompanyName,
        UserId:req.params.id,
        ProductId:req.body.ProductId,
        ProductName:req.body.ProductName,
        Packs:req.body.Packs,
        CalculatedStamps:req.body.CalculatedStamps
    })
  
    const result = joiSchema.validate(body,Product);
    const  {value , error} = result;
    const valid  = error == null;
    if(!valid){
      res.json({
          error:error
      })
    }
    
        else{
            const a1 = await Product.findOne({UserId:alien.UserId})
            const b1 = await Product.findOneAndUpdate({ProductId: alien.ProductId}, {$set:{ProductName: alien.ProductName,Packs: alien.Packs,CalculatedStamps:alien.CalculatedStamps}})
            if(a1 && b1.CompanyName !== alien.CompanyName){
                res.json({error : "Could not update Product Please try again."})
            }
            else{
                res.json({message : "Updated Product details successfully !!"})
            }
        }
    
})


module.exports = router;