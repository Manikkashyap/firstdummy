const express = require('express')
const router = express.Router()
const Login = require('../models/login')
const Alien = require('../models/signup')
const Joi = require('joi');



router.post('/', async(req,res) => {
   
    const joiSchema = Joi.object().keys({ 
        Email: Joi.string().email().required(),
        Password: Joi.string().alphanum().min(3).max(30).required(),
      }); 

      const { body } = req;
    const alien = new Login({
        Email: req.body.Email,
        Password:req.body.Password
    })

    const result = joiSchema.validate(body, Alien); 
     const { value, error } = result; 
     const valid = error == null; 
     console.log(value  , " error>>> " , error , body)
     if (!valid) { 
        res.status(422).json({ 
          message: 'Invalid request', 
          data: error
        })
      }
    else{
    const a1 =  await Alien.findOne({ Email : alien.Email});  
    if(a1 !== null){
        if(a1.Password !== req.body.Password){
            console.log("password doesn't match")
            res.json({error : "password doesn't match"})
        } 
       else{
        console.log(`hey ${a1.Username} you have logged in sucessfully !!`)
        res.json({loginStatus : true , id : a1._id ,name: a1.Username})
       }
    }
    else{
        console.log("Please provide right credentials")
        res.json({error:"Please provide valid email "})
    }
    }
})



module.exports = router