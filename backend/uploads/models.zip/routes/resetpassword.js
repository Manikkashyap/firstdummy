const express = require('express')
const router = express.Router()
const Reset = require('../models/resetPass')
const Alien = require('../models/signup')
const Joi = require('joi');


router.put('/' ,async(req,res)=>{
    const joiSchema = Joi.object().keys({
        CPassword: Joi.string().alphanum().min(3).max(30).required(),
        Password: Joi.string().alphanum().min(3).max(30).required(),
        Id: Joi.string().required(),
      });  
      const { body } = req;
    const alien = new Reset({
        Id:req.body.Id,
        CPassword:req.body.CPassword,
        Password:req.body.Password,
        
    })
    const result = joiSchema.validate(body, Reset); 
    const { value, error } = result; 
    const valid = error == null; 
    console.log(" error>>> " , error)
    if (!valid) { 
        res.status(422).json({ 
          message: 'Invalid request', 
          data: error
        })
      } 
      else { 
          const a1 = await Alien.findOne({_id : alien.Id})
          if(a1){
            if(a1.Password !== alien.CPassword){
                res.json({error : "Please provide current password again"})
            }
            else{
                Alien.findOneAndUpdate({Password : alien.CPassword}, {$set:{Password: alien.Password}}, {new: true}, (err, doc) => {
                    if (err) {
                       res.json({message : "Something wrong when updating data!"});
                    }
                
                    res.json({result : doc});
                });
            }
          }
          else{
              res.json({error : "User is not found !!" })
          }
      } 
})
module.exports = router