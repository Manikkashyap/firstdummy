const express = require('express')
const router = express.Router()
const Search = require('../models/search')
const Joi = require('joi');



router.post('/' , async(req,res)=>{
    const joiSchema = Joi.object().keys({
        ECPName: Joi.string().min(3).max(30).required(),
        Address:Joi.string().min(3).max(30).required(),
        PhoneNumber:Joi.number().required(),
        UserId:Joi.number().required(),

    });
    const {body} = req;
    const alien = new Search({
        ECPName:req.body.ECPName,
        Address:req.body.Address,
        PhoneNumber:req.body.PhoneNumber,
        UserId:req.body.UserId,
     
    })
    console.log(body)
     const result = joiSchema.validate(body,Search); 
     const {error } = result;  
     const valid = error == null; 
     if(!valid){
        res.json({
            validationerror:error
        })
     }
     else{
        const a1 =  await Search.findOne({ECPName : alien.ECPName}  && {UserId : alien.UserId})
        // console.log(a1)
            if(a1 !== null){
                res.json({failure: " comanpany already registered in website !!"})
            }
            else{
                const b1 = await alien.save()
                res.json({success : "Your Data has been saved successfully "})
            }
     }
})


// SEARCH FUNCITON 
router.get('/' , async(req,res)=>{
       const search = req.query.search; // THIS IS COMING FROM QUERY IN WEB APP
        var pageNo = parseInt(req.query.pageNo) // PAGINATED SEARCH HAI BUT ISE HTA SKTE 
        var size = parseInt(req.query.size)
            var query = {}
        if(pageNo < 0 || pageNo === 0) {
              response = {"error" : true,"message" : "invalid page number, should start with 1"};
              return res.json(response)
        }
        query.skip = size * (pageNo - 1)
        query.limit = size
             // ESE SEARCH KRNA METHOD YHI HAI SAME BAKI DOUBT HO TOH SEARCH KRNA MIL JANA 
             Search.find({ECPName : { $regex : search  , $options : '$i' }},{},query,function(err,data) {
                // Search.estimatedDocumentCount({},(err , count)=>{
                //     console.log(">>>>>>>>>>>>>>>>>>>>>>" , count)
                //   })
                  if(err) {
                      response = {"error" : true,"message" : "Error fetching data"};
                  } else {

                      response = {"error" : false,"message" : data};
                      
                  }
                  res.json({data : data})
              })
              
           
});



router.get('/:id' , async(req,res)=> {
    const alien = new Search({
        UserId : req.params.id
    })
    const a1 = await Search.findOne({UserId: alien.UserId})
    if(a1){
        res.json(a1)
    }
    else {
        res.json({error : "Not Found any data !!"})
    }
})

    


router.put('/' , async(req,res)=>{
    const joiSchema = Joi.object().keys({
        ECPName: Joi.string().min(3).max(30).required(),
        Address:Joi.string().min(3).max(30).required(),
        PhoneNumber:Joi.number().required(),
        UserId:Joi.number().required(),

    });
    const {body} = req;
    const alien = new Search({
        ECPName:req.body.ECPName,
        Address:req.body.Address,
        PhoneNumber:req.body.PhoneNumber,
        UserId:req.body.UserId,
   
    })
    console.log(body)
     const result = joiSchema.validate(body,Search); 
     const { value, error } = result; 
     const valid = error == null; 
     if(!valid){
        res.json({
            error:error
        })
     }
     else{
        const a1 = await Search.findOne({UserId: alien.UserId})
        if(a1){
            Search.findOneAndUpdate({UserId: alien.UserId}, {$set:{Address: alien.Address,ECPName: alien.ECPName,PhoneNumber:alien.PhoneNumber,UserId:alien.UserId}}, {new: true}, (err, doc) => {
                if (err) {
                   res.json({message : "Something wrong when updating data!"});
                }
            else{
                res.json({result : doc});
            }
            });
        }
        else{
            res.json({error : "did not find any data"})
        }
    }
}) 


router.delete('/:id' , async(req,res)=>{
    

    const id = req.params.id;
    // console.log(id); // 
        const a1 = await Search.findOneAndDelete({UserId :id})
        // console.log(req.params)
        res.json({message : "company data deleted !!"})
    

})

module.exports = router