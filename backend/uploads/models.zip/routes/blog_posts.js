const express = require('express')
const router = express.Router()
const Posts = require('../models/blogs_posts')



router.post('/' , async(req,res)=>{
    const { body } = req;
    const posts = new Posts({
        blog_title:req.body.blog_title,
        blog_content:req.body.blog_content,
        time_to_read:req.body.time_to_read,
        published_location:req.body.published_location,
        blog_image_Url:req.body.blog_image_Url,

    })
    const a1 =  await posts.save() 
    res.json(a1)
})


module.exports = router ; 


