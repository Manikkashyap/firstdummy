const express = require('express')
const router = express.Router()
const Alien = require('../models/signup')
const Joi = require('joi');


router.get('/' ,async(req,res)=>{
   try{
          const aliens = await Alien.find()
          res.json(aliens)
   }catch(error){
      console.log(error)
   }
})

router.post('/createuser', async(req,res) => {
    const joiSchema = Joi.object().keys({ 
        Username: Joi.string().alphanum().min(3).max(30).required(),
        Email: Joi.string().email().required(),
        Password: Joi.string().alphanum().min(3).max(30).required(),
      });  
    const { body } = req;
    const alien = new Alien({
        Username:req.body.Username,
        Email:req.body.Email,
        Password:req.body.Password,
    })
     const result = joiSchema.validate(body, Alien); 
     const { value, error } = result; 
     const valid = error == null; 
     console.log(value  , " error>>> " , error , body)
     if (!valid) { 
        res.status(422).json({ 
          message: 'Invalid request', 
          data: error
        })
      } else { 
        const a1 =  await Alien.findOne({ Email  : alien.Email });
        if(a1){
            res.json({error : "User Email is already registered."})
        }
        else{
            const a1 =  await alien.save() 
            console.log(a1)
            res.json(a1)
        }
      } 
        
       
    
})


router.get('/:email&:password', async(req,res)=>{

    try{
        const aliens = await Alien.find({password:req.params.password , email:req.params.email})
        res.json(aliens)
 }catch(error){
    console.log(error)
 }
})

module.exports = router