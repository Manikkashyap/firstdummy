const mongoose = require('mongoose')

const searchSchema = mongoose.Schema({
    ECPName:{
        type:String,
        required:true
    },
    Address:{
        type:String,
        required:true
    },
    PhoneNumber:{
        type:Number,
        required:true
    },
    UserId:{
        type:Number,
        required:true
    }

})


module.exports = mongoose.model ('Search', searchSchema)