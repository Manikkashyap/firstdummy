const { number } = require('joi')
const mongoose = require('mongoose')



const productSchema = mongoose.Schema({
    CompanyName:{
        type:String,
        required:true
    },
    UserId:{
      type:Number,
      required:true
    },
    ProductId:{
        type:Number,
        required:true
    },
    ProductName:{
        type:String,
        required:true
    },
    Packs:{
        type:Number,
        required:true
    },
    CalculatedStamps:{
        type:Number,
        required:true
    }
})



module.exports = mongoose.model('Product', productSchema);