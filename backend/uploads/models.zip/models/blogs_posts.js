const mongoose = require('mongoose')

const blogSchema = new mongoose.Schema({
    blog_title: {
        type: String,
       
    },
    blog_content: {
        type: String,
       
    },
    time_to_read:{
        type:Number,
    },
    published_location : {
        type:String,
    },
    blog_image_Url : {
        type : String,
    }

})




module.exports = mongoose.model('blog_posts',blogSchema)