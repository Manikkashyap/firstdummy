const mongoose = require('mongoose')

const resetSchema = mongoose.Schema({
    Id:{
        type:String,
        required:true
    },
    CPassword:{
        type:String,
        required:true
    },
    Password:{
        type:String,
        required:true
    }
})



module.exports = mongoose.model('Reset' , resetSchema)